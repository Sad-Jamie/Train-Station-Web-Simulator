package com.grouptwo.service;

import com.grouptwo.entity.StationList;

public interface StationService {
	
	public StationList AllStations();
	

}
