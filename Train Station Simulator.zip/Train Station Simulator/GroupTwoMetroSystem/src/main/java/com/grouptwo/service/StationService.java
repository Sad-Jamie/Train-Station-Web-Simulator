package com.grouptwo.service;

import java.util.Collection;

import com.grouptwo.entity.Station;

public interface StationService {
	
	public Collection<Station> getAllStations();
}
